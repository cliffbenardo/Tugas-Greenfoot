import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;
import java.util.ArrayList;
/**
 * Write a description of class road here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class road extends World
{
    private int counter = 0;

    Random r = new Random();
    /**
     * Constructor for objects of class road.
     * 
     */
    public road()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(510, 650, 1,false); 
        
        addObject(new binatang(),getWidth()/2,getHeight()*3/4);
        act();
    }
    
    public int[] remove(int[] arr, int index){
        int[] newarr = new int[arr.length - 1];
        
        
        for( int i = 0, k = 0; i < arr.length ; i++){
            if (i == index) continue;
            newarr[k++] = arr[i];
        }
            
            
        return newarr;
        
        
    }
    
    public void act(){
        counter++;
        
        int[] position = {1,3,5,7};

        int n=4;
         
        
        if (counter == 100) {
            
            for(int i = 0 ; i < r.nextInt(2)+2; i++){
                Obstacle[] cars = {new blue(),new red()};
                int choice = r.nextInt(position.length);
                addObject(cars[r.nextInt(cars.length)],getWidth() * (position[choice])/8,-100);

                position = remove(position,choice);
 
            }
            
            counter = 0;
        }
        
        
    }
}
