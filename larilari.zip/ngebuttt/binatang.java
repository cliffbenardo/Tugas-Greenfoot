import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class binatang here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class binatang extends Actor
{
    String key_before;
    /**
     * Act - do whatever the binatang wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
    
        // Add your action code here.
        if(Greenfoot.isKeyDown("right") && getX() < getWorld().getWidth()*7/8){
            getImage().mirrorHorizontally();
            setLocation(getX()+7,getY());
        }
        else if(Greenfoot.isKeyDown("left") && getX() > getWorld().getWidth()/8){
            getImage().mirrorHorizontally();
            setLocation(getX()-7,getY());
        }


        if(isTouching(Obstacle.class)){
            getWorld().addObject(new mampus(), getX(),getY());
            Greenfoot.stop();
        }
    }    
}
